async function saveDataToLocalStorage(data) {
	return new Promise((resolve, reject) => {
		chrome.storage.local.set(data, () => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(true);
		});
	});
}

async function readDataFromLocalStorage(data) {
	return new Promise((resolve, reject) => {
		chrome.storage.local.get(data, (result) => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(result);
		});
	});
}

document.addEventListener('DOMContentLoaded', async () => {
  const statusBox = document.getElementById('statusBox');
  const oneCourierBigFontCheckbox = document.getElementById('oneCourierBigFontCheckbox');
  let readedValue;
  try {
    readedValue = await readDataFromLocalStorage(['oneCourierBigFont']);
  } catch (error) {
    statusBox.innerText = `Błąd! Nie udało się wczytać ustawień. ${error instanceof Error ? error.message : error}`;
    return Promise.reject(false);
  }

  if (readedValue.oneCourierBigFont !== undefined) {
    oneCourierBigFontCheckbox.checked = readedValue.oneCourierBigFont;
  }

  oneCourierBigFontCheckbox.addEventListener('change', async (e) => {
    try {
			await saveDataToLocalStorage({ oneCourierBigFont: e.target.checked });
		} catch (error) {
			statusBox.innerText = `Błąd! Nie udało się zmienić ustawień. ${error instanceof Error ? error.message : error}`;
			return Promise.reject(false);
		}
    statusBox.innerText = 'Zapisano';
    const delay = t => new Promise(resolve => setTimeout(resolve, t));
		await	delay(3000);
    statusBox.innerHTML = '&nbsp;';
  })
});