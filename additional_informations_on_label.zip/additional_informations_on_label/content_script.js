if (document.getElementById('pdfLibScript') === null) {
  var s = document.createElement('script');
  s.id = 'pdfLibScript';
  s.src = chrome.runtime.getURL('pdf-lib.js');
  (document.head||document.documentElement).appendChild(s);
  s.onload = function() {
    s.remove();
  };
}

if (document.getElementById('fontkitScript') === null) {
  var f = document.createElement('script');
  f.id = 'fontkitScript';
  f.src = chrome.runtime.getURL('fontkit.umd.js'); 
  (document.head||document.documentElement).appendChild(f);
  f.onload = function() {
    f.remove();
  };
}

window.addEventListener('load', () => {
  console.log('*** content script load event fired');  
  if (window.location.href.search(/https:\/\/allegro.pl(?:.allegrosandbox.pl|)\/moje-allegro\/sprzedaz\/wysylam\/nadaj-paczke/) === 0) {
    (function findSaveButton() {
      let saveButton = Array.from(document.querySelectorAll('button')).find(element => element.textContent === 'Zapisz');
      if (saveButton !== undefined) {
        saveButton.addEventListener('click', () => {
          let shippingMethod = Array.from(document.querySelectorAll('p')).find(element => element.innerText === 'PRZEWOŹNIK')?.nextElementSibling.innerText;
          if (['Allegro One Punkt', 'Allegro One Box'].indexOf(shippingMethod) === -1) {
            return;
          }
          let parcelDescription = document.getElementById('parcel_description_0')?.value;
          let parcelReferenceNumber = document.getElementById('parcel_reference_number_0')?.value;
          let orderId = document.querySelector('input[id*="parcel_type_"]')?.id.slice(12, 48);
          if (orderId) {
            parcelDescription = parcelDescription ?? '';
            parcelReferenceNumber = parcelReferenceNumber ?? '';
            chrome.storage.session.set({
              [`${orderId}`]: {
                description: parcelDescription.replaceAll('\n', '; '),
                referenceNumber: parcelReferenceNumber
              }
            }).catch(error => {
              alert(`Podczas zapisywania danych do wydruku w pamięci wystąpił błąd, szczegóły (oryginalna treść wiadomości): ${error.message}`);
              return;
            });
          } else {
            alert('Nie znaleziono numeru zamówienia, plik nie zostanie przetworzony.');
            return;
          }
        });
      } else {
        const delay = t => new Promise(resolve => setTimeout(resolve, t));
				delay(500).then(() => {
          findSaveButton();
          return;
        });
      }
    })();
  } else if (window.location.href.search(/https:\/\/allegro.pl(?:.allegrosandbox.pl|)\/moje-allegro\/sprzedaz\/wysylam\/wza\/nadaj-paczke-status/) === 0) {
    const orderId = new URL(document.referrer)?.searchParams.get('orderId');
    if (!orderId) {
      alert('Nie znaleziono numeru zamówienia, plik nie zostanie przetworzony.');
      return;
    }
    chrome.storage.session.get([`${orderId}`]).then(response => {
      if (Object.keys(response).length === 0) return;
      const description = `${response[`${orderId}`].description}`;
      const referenceNumber = `${response[`${orderId}`].referenceNumber}`;
      (function findDownloadButton() {
        let downloadButton = Array.from(document.querySelectorAll('button')).find(element => element.textContent === 'Pobierz etykiety');
        if (downloadButton !== undefined) {
          downloadButton.addEventListener('click', downloadLabelButtonClick.bind(null, description, referenceNumber));
          downloadButton.style.backgroundColor = 'lightgreen';
        } else {
          const delay = t => new Promise(resolve => setTimeout(resolve, t));
          delay(500).then(() => {
            findDownloadButton();
            return;
          });
        }
      })();
    }).catch(error => {
      alert(`Błąd podczas odczytywania danych do wydruku z pamięci, szczegóły (oryginalna treść wiadomości): ${error.message}`);
      return;
    });
  }
});  

function downloadLabelButtonClick(description, referenceNumber) {
  chrome.runtime.sendMessage({action: 'downloadLabel'}).then(response => {
    if (response.filename && response.id && (description || referenceNumber)) {
      processPDF(response.filename, response.id, description, referenceNumber).catch(error => {
        alert(error); 
        return;
      });
    } else {
      alert('Błąd, nie znaleziono danych potrzebnych do zmodyfikowania etykiety. Plik nie zostanie przetworzony.');
    }
  }).catch(error => {
    alert(`${(error.name !== 'customError' ? 'Błąd podczas pobierania etykiety, szczegóły (oryginalna treść wiadomości): ' : '')}${error.message}`); 
    return;
  });
}
  
async function processPDF(filename, id, description, referenceNumber) {
  const { PDFDocument, grayscale } = PDFLib;
  const url = chrome.runtime.getURL(filename);
  const arrayBuffer = await fetch(url).then(result => result.arrayBuffer()).catch(error => { return Promise.reject(`Błąd podczas ładowania etykiety, szczegóły (oryginalna treść wiadomości): ${error.message}`) });
  const pdfDoc = await PDFDocument.load(arrayBuffer);
  const fontUrl = chrome.runtime.getURL('OpenSans-Regular.ttf');
  const fontBytes = await fetch(fontUrl).then(result => result.arrayBuffer()).catch(error => { return Promise.reject(`Błąd podczas wczytywania czcionki, szczegóły (oryginalna treść wiadomości): ${error.message}`) });
  pdfDoc.registerFontkit(fontkit);
  const customFont = await pdfDoc.embedFont(fontBytes, {subset: true }).catch(error => { return Promise.reject(`Błąd podczas osadzania czcionki, szczegóły (oryginalna treść wiadomości): ${error.message}`) });
  const pages = pdfDoc.getPages();
  if (pages.length > 1) return Promise.reject('Obsługiwane są tylko pliki zawierające jedną stronę! Plik nie zostanie przetworzony.');
  await chrome.runtime.sendMessage({action: 'removeLabel', downloadItemId: id}).catch(error => { return Promise.reject(`${(error.name !== 'customError' ? 'Błąd podczas usuwania etykiety, szczegóły (oryginalna treść wiadomości): ' : '')}${error.message}`) });
  const firstPage = pages[0];
  firstPage.setLineHeight(16);
  firstPage.setFont(customFont);
  firstPage.setFontSize(12);
  firstPage.setFontColor(grayscale(0));
  const { width, height } = firstPage.getSize();

  let wrappedText = await wrapText(description, width - 10, customFont, 12);

  firstPage.drawText(wrappedText, {
    x: 5,
    y: height - 370,
  });

  firstPage.drawText(referenceNumber, {
    x: 5,
    y: height - 370 - (wrappedText.split('\n').length * 16),
  });

  const pdfBytes = await pdfDoc.saveAsBase64({ dataUri: true });
  let downloadLink = document.createElement('a');
  downloadLink.href = pdfBytes;
  downloadLink.download = filename.slice(filename.lastIndexOf('/') + 1);
  downloadLink.click();
  return Promise.resolve(true);
};

async function wrapText(text, width, font, fontSize) {
  const words = text.split(' ');
  let line = '';
  let result = '';
  for (let n = 0; n < words.length; n++) {
    const testLine = line + words[n] + ' ';
    const testWidth = font.widthOfTextAtSize(testLine, fontSize);
    if (testWidth > width) {
      result += line + '\n';
      line = words[n] + ' ';
    } else {
      line = testLine;
    }
  }
  result += line;
  return Promise.resolve(result);
}