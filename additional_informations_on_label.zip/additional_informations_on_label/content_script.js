if (document.getElementById('pdfLibScript') === null) {
  var s = document.createElement('script');
  s.id = 'pdfLibScript';
  s.src = chrome.runtime.getURL('pdf-lib.js');
  (document.head||document.documentElement).appendChild(s);
  s.onload = function() {
    s.remove();
  };
}

if (document.getElementById('fontkitScript') === null) {
  var f = document.createElement('script');
  f.id = 'fontkitScript';
  f.src = chrome.runtime.getURL('fontkit.umd.js'); 
  (document.head||document.documentElement).appendChild(f);
  f.onload = function() {
    f.remove();
  };
}

async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(result); 
    });
  });
}

async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response);
		});
	});
}

window.addEventListener('load', async () => {
  console.log('Załadowano skrypt additionalInformationsOnLabel'); 
  let readedValue;
  try {
    readedValue = await readDataFromLocalStorage(['oneCourierBigFont']);
  } catch (error) {
    alert(`Błąd! Nie udało się wczytać ustawień. ${error.message}`);
    return Promise.reject(false);
  }

  let previousUrl;
	const urlObserver = new MutationObserver(() => {
		if (window.location.href !== previousUrl) {
			previousUrl = window.location.href;
			if (window.location.href.search(/https:\/\/allegro.pl(?:.allegrosandbox.pl|)\/moje-allegro\/sprzedaz\/wysylam\/wza\/nadaj-paczke-status/) === 0) {
        waitForPageChange(parameters);
      }
			return;
		}
	});
  urlObserver.observe(document, { subtree: true, childList: true });
  
  const parameters = {
    carrier: '',
    shippingMethod: '',
    orderId: window.location.href.substring(window.location.href.length - 36),
    description: '',
    referenceNumber: '',
    oneCourierBigFont: readedValue.oneCourierBigFont
  }
  findSaveButton(parameters); 
});

function findSaveButton(parameters) {
  let saveButton = Array.from(document.querySelectorAll('button')).find(element => element.textContent === 'Zapisz');
  if (saveButton === undefined) {
    const delay = t => new Promise(resolve => setTimeout(resolve, t));
    delay(500).then(() => {
      findSaveButton(parameters);
    });
    return;
  }

  parameters.shippingMethod = Array.from(document.querySelectorAll('span')).find(element => element.innerText === 'METODA DOSTAWY')?.nextElementSibling?.innerText;
  if (parameters.shippingMethod === undefined) {
    const delay = t => new Promise(resolve => setTimeout(resolve, t));
    delay(500).then(() => {
      findSaveButton(parameters);
    });
    return;
  }

  if (['Allegro One Punkt', 'Allegro One Box', 'Allegro One Box, One Kurier', 'Allegro One Punkt, One Kurier', 'Allegro One Kurier - dostawa jutro', 'Allegro One Kurier pobranie - dostawa jutro', 'Allegro One Box, One Kurier - dostawa dzisiaj'].indexOf(parameters.shippingMethod) === -1) {
    return;
  } 
  parameters.carrier = ((parameters.shippingMethod === 'Allegro One Punkt' || parameters.shippingMethod === 'Allegro One Box') ? 'UPS' : 'One Kurier'); 

  saveButton.addEventListener('click', () => {  
    parameters.description = document.getElementsByName('additionalInfoOnLabel')?.[0]?.value;
    parameters.referenceNumber = document.getElementsByName('referenceNumber')?.[0]?.value;
  });
}

async function waitForPageChange(parameters) {
  const delay = t => new Promise(resolve => setTimeout(resolve, t));
  await delay(100);
  if (!parameters.orderId) {
    alert('Nie znaleziono numeru zamówienia, plik nie zostanie przetworzony.');
    return;
  }

  if (!parameters.carrier) return;

  async function findDownloadButton() {
    let downloadButton = Array.from(document.querySelectorAll('button')).find(element => element.textContent === 'Pobierz etykiety');
    if (downloadButton === undefined) {
      const delay = t => new Promise(resolve => setTimeout(resolve, t));
      await delay(500);
      findDownloadButton();
      return;
    }   
    downloadButton.addEventListener('click', downloadLabelButtonClick.bind(null, parameters.description, parameters.referenceNumber, parameters.carrier));
    downloadButton.style.backgroundColor = 'lightgreen'; 
  }

  if (parameters.carrier === 'UPS' || (parameters.carrier === 'One Kurier' && parameters.oneCourierBigFont)) findDownloadButton();
}

async function downloadLabelButtonClick(description, referenceNumber, carrier) {
  let response;
  try {
    response = await sendMessage({ action: 'downloadLabel' });
    if (response.success === false) throw new Error(response.result);
  } catch (error) {
    alert(error instanceof Error ? error.message : error);
    return Promise.reject(false);
  }

  if (response.result.filename && response.result.id && (description || referenceNumber) && carrier) {
    if (carrier === 'UPS') {
      try {
        await processPDFUPS(response.result.filename, response.result.id, description, referenceNumber);
      } catch (error) {
        alert(error instanceof Error ? error.message : error);
        return Promise.reject(false);
      }
      return Promise.resolve(true);
    } else {
      try {
        await processPDFOneKurier(response.result.filename, response.result.id, description, referenceNumber);
      } catch (error) {
        alert(error instanceof Error ? error.message : error); 
        return Promise.reject(false);
      }
    }   
  } else {
    alert('Błąd, nie znaleziono danych potrzebnych do zmodyfikowania etykiety. Plik nie zostanie przetworzony.');
  }
}
  
async function processPDFUPS(filename, id, description, referenceNumber) {
  const { PDFDocument, grayscale } = PDFLib;
  const url = chrome.runtime.getURL(filename);
  const arrayBuffer = await fetch(url).then(result => result.arrayBuffer()).catch(error => { return Promise.reject(`Błąd podczas ładowania etykiety. ${error.message}`) });
  const pdfDoc = await PDFDocument.load(arrayBuffer);
  const fontUrl = chrome.runtime.getURL('OpenSans-Regular.ttf');
  const fontBytes = await fetch(fontUrl).then(result => result.arrayBuffer()).catch(error => { return Promise.reject(`Błąd podczas wczytywania czcionki. ${error.message}`) });
  pdfDoc.registerFontkit(fontkit);
  const customFont = await pdfDoc.embedFont(fontBytes, {subset: true }).catch(error => { return Promise.reject(`Błąd podczas osadzania czcionki. ${error.message}`) });
  const pages = pdfDoc.getPages();
  if (pages.length > 1) return Promise.reject('Obsługiwane są tylko pliki zawierające jedną stronę! Plik nie zostanie przetworzony.');
  let response;
  try {
    response = await chrome.runtime.sendMessage({ action: 'removeLabel', downloadItemId: id });
    if (response.success === false) throw new Error(response.result);
  } catch (error) {
    return Promise.reject(`Błąd podczas usuwania etykiety. ${error instanceof Error ? error.message : error}`);
  }
  
  const firstPage = pages[0];
  firstPage.setLineHeight(16);
  firstPage.setFont(customFont);
  firstPage.setFontSize(12);
  firstPage.setFontColor(grayscale(0));
  const { width, height } = firstPage.getSize();

  let wrappedText = await wrapText(description, width - 10, customFont, 12);

  firstPage.drawText(wrappedText, {
    x: 5,
    y: height - 370,
  });

  firstPage.drawText(referenceNumber, {
    x: 5,
    y: height - 370 - (wrappedText.split('\n').length * 16),
  });

  const pdfBytes = await pdfDoc.saveAsBase64({ dataUri: true });
  let downloadLink = document.createElement('a');
  downloadLink.href = pdfBytes;
  downloadLink.download = filename.slice(filename.lastIndexOf('/') + 1);
  downloadLink.click();
  return Promise.resolve(true);
};

async function processPDFOneKurier(filename, id, description, referenceNumber) {  
  const { PDFDocument, grayscale } = PDFLib;
  const url = chrome.runtime.getURL(filename);
  const arrayBuffer = await fetch(url).then(result => result.arrayBuffer()).catch(error => { return Promise.reject(`Błąd podczas ładowania etykiety. ${error.message}`) });
  const pdfDoc = await PDFDocument.load(arrayBuffer);
  const fontUrl = chrome.runtime.getURL('OpenSans-Regular.ttf');
  const fontBytes = await fetch(fontUrl).then(result => result.arrayBuffer()).catch(error => { return Promise.reject(`Błąd podczas wczytywania czcionki. ${error.message}`) });
  pdfDoc.registerFontkit(fontkit);
  const customFont = await pdfDoc.embedFont(fontBytes, {subset: true }).catch(error => { return Promise.reject(`Błąd podczas osadzania czcionki. ${error.message}`) });
  const pages = pdfDoc.getPages();
  if (pages.length > 1) return Promise.reject('Obsługiwane są tylko pliki zawierające jedną stronę! Plik nie zostanie przetworzony.');
  let response;
  try {
    response = await chrome.runtime.sendMessage({ action: 'removeLabel', downloadItemId: id });
    if (response.success === false) throw new Error(response.result);
  } catch (error) {
    return Promise.reject(`Błąd podczas usuwania etykiety. ${error instanceof Error ? error.message : error}`);
  }

  const firstPage = pages[0];
  firstPage.setLineHeight(14);
  firstPage.setFont(customFont);
  firstPage.setFontSize(10);
  firstPage.setFontColor(grayscale(0));
  const { width, height } = firstPage.getSize();

  firstPage.drawRectangle({
    x: 103,
    y: 83,
    width: 162,
    height: 55,
    borderColor: grayscale(1),
    borderWidth: 1,
    color: grayscale(1)
  });

  let wrappedText = await wrapText(description, 160, customFont, 10);

  firstPage.drawText(wrappedText, {
    x: 103,
    y: height - 306,
  });

  firstPage.drawText(referenceNumber, {
    x: 103,
    y: height - 306 - (wrappedText.split('\n').length * 14),
  });

  const pdfBytes = await pdfDoc.saveAsBase64({ dataUri: true });
  let downloadLink = document.createElement('a');
  downloadLink.href = pdfBytes;
  downloadLink.download = filename.slice(filename.lastIndexOf('/') + 1);
  downloadLink.click();
  return Promise.resolve(true);
};

async function wrapText(text, width, font, fontSize) {
  const words = text.split(' ');
  let line = '';
  let result = '';
  for (let n = 0; n < words.length; n++) {
    const testLine = line + words[n] + ' ';
    const testWidth = font.widthOfTextAtSize(testLine, fontSize);
    if (testWidth > width) {
      result += line + '\n';
      line = words[n] + ' ';
    } else {
      line = testLine;
    }
  }
  result += line;
  return Promise.resolve(result);
}